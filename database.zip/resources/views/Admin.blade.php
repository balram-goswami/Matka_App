@include('Admin/Include/Header')

@include($view)

@include('Admin/Include/Footer')