<!-- CSS Libraries -->
<link rel="stylesheet" href="{{ publicPath('/themeAssets/css/bootstrap.min.css') }}">
<link rel="stylesheet" href="{{ publicPath('/themeAssets/css/tabler-icons.min.css') }}">
<link rel="stylesheet" href="{{ publicPath('/themeAssets/css/animate.css') }}">
<link rel="stylesheet" href="{{ publicPath('/themeAssets/css/owl.carousel.min.css') }}">
<link rel="stylesheet" href="{{ publicPath('/themeAssets/css/magnific-popup.css') }}">
<link rel="stylesheet" href="{{ publicPath('/themeAssets/css/nice-select.css') }}">
<!-- Stylesheet -->
<link rel="stylesheet" href="{{ publicPath('/themeAssets/style.css') }}">
<!-- Web App Manifest -->
<link rel="manifest" href="{{ publicPath('/themeAssets/manifest.json') }}">