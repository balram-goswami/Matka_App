@include('Include/Header')

@include($view)

@include('Include/Footer')