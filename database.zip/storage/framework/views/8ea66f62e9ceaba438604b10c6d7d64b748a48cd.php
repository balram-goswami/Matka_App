
</div>

<?php echo $__env->make('Include.Script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

<script>
    // Pass the user_id and role from Laravel to JavaScript
    const userId = <?php echo json_encode(Auth::user() ? Auth::user()->user_id : null, 15, 512) ?>;
    const userRole = <?php echo json_encode(Auth::user() ? Auth::user()->role : null, 15, 512) ?>;

    // Check if user_id is not null and user_role is not 'user'
    if (userId !== null && userRole !== 'user') {
        // Redirect to the welcome page
        window.location.href = '/'; 
    }
</script>

</html>
<?php /**PATH C:\xampp\htdocs\Matka_app\resources\views/Include/Footer.blade.php ENDPATH**/ ?>