<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class UserMetas extends Model
{
	/**Table Name**/
	protected $table = 'user_metas';
}
