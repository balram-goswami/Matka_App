<div class="container-xxl flex-grow-1 container-p-y">
    <div class="card mb-4">
        <div class="card">
            <h5 class="card-header">Deposit Request</h5>
            <div class="table-responsive text-nowrap">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>User</th>
                            <th>UTR No.</th>
                            <th>Message</th>
                            <th>Amount</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody class="table-border-bottom-0">
                        <?php $__currentLoopData = $payment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                        $userName = getUserName($list->user_id);
                        ?>
                        <?php if($list->withdraw_amount == NULL): ?>
                        <tr>
                            <td><?php echo e($userName->name); ?></td>
                            <td><?php echo e($list->utr_number); ?></td>
                            <td><?php echo e($list->remark); ?></td>
                            <td><?php echo e($list->deposit_amount); ?></td>
                            <td>
                                <?php if($list->request_status === 'pending'): ?>
                                <span class="badge bg-label-success me-1">Pending</span>
                                <?php else: ?>
                                <span class="badge bg-label-primary me-1">Complete</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if($list->request_status === 'pending'): ?>
                                <a href="<?php echo e(route('confermPayment', $list->id)); ?>">Conferm</a>
                                <?php else: ?>
                                <span class="badge bg-label-primary me-1">No Action Needed</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<div class="container-xxl flex-grow-1 container-p-y">
    <div class="card mb-4">
        <div class="card">
            <h5 class="card-header">Withdral Request</h5>
            <div class="table-responsive text-nowrap">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>User</th>
                            <th>Wallet Balance</th>
                            <th>Amount</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody class="table-border-bottom-0">
                        <?php $__currentLoopData = $payment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                        $userName = getUserName($list->user_id);
                        $walletBalance = DB::table('wallets')->where('user_id', $list->user_id)->get()->first();
                        ?>

                        <?php if($list->deposit_amount == NULL): ?>
                        <tr>
                            <td><?php echo e($userName->name); ?></td>
                            <td><?php echo e($walletBalance->balance); ?></td>
                            <td><?php echo e($list->withdraw_amount); ?></td>
                            <td>
                                <?php if($list->request_status === 'pending'): ?>
                                <span class="badge bg-label-success me-1">Pending</span>
                                <?php else: ?>
                                <span class="badge bg-label-primary me-1">Complete</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if($list->request_status === 'pending'): ?>
                                <a href="<?php echo e(route('viewPayment', $list->id)); ?>"> View </a>
                                <?php else: ?>
                                <span class="badge bg-label-primary me-1">Payment Done</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\Matka_app\resources\views/Admin/Results/PaymentPage.blade.php ENDPATH**/ ?>