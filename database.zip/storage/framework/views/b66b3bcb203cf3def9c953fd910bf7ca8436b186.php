<div class="container-xxl flex-grow-1 container-p-y">
    <!-- Basic Bootstrap Table -->
    <div class="card mb-4">
        <div class="card-header d-flex justify-content-between align-items-center">
            <h4 class="fw-bold py-3 mb-0 pull-left">Voting Game Result </h4>
        </div>
        <div class="card-body">
            <div class="table-responsive text-nowrap">
                <form method="POST" action="<?php echo e(route('gameResult')); ?>" id="game_result">
                    <?php echo csrf_field(); ?>
                    <div class="row mb-3">
                        <div class="col-sm-4">
                            <div class="input-group input-group-merge">
                                <select name="game_id" id="gameid" class="form-control">
                                    <option value="">Select Option</option>
                                    <?php $__currentLoopData = $numberGame; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $choice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(isset($choice['extraFields']['close_date']) && $choice['extraFields']['close_date'] >= dateonly()): ?>
                                    <option value="<?php echo e($choice->post_id); ?>"><?php echo e($choice->post_title); ?></option>
                                    <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>

                        <div class="col-sm-4">
                            <select name="result" id="result" class="form-control">
                                <option value="">Select Option</option>
                            </select>
                        </div>

                        <div class="col-sm-4">
                            <button type="submit" class="btn btn-primary">Save</button>
                        </div>
                    </div>
                    <br>
                </form>

            </div>
        </div>
    </div>
    <!--/ Basic Bootstrap Table -->
</div>

<div class="container-xxl flex-grow-1 container-p-y">
    <!-- Basic Bootstrap Table -->
    <div class="card mb-4">
        <div class="card-header d-flex justify-content-between align-items-center">
            <h4 class="fw-bold py-3 mb-0 pull-left">Satta Result </h4>
        </div>
        <div class="card-body">
            <div class="table-responsive text-nowrap">
                <form method="POST" action="<?php echo e(route('sattaResult')); ?>" id="satta_result">
                    <?php echo csrf_field(); ?>
                    <div class="row mb-3">
                        <div class="col-sm-4">
                            <div class="input-group input-group-merge">
                                <select name="game_id" id="game_id" class="form-control">
                                    <option value="">Select Game</option>
                                    <?php $__currentLoopData = $sattaGame; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $satta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($satta->post_id); ?>"><?php echo e($satta->post_title); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>

                        <div class="col-sm-4">
                            <input name="result" id="result" class="form-control" placeholder="Enter Result"></input>
                        </div>

                        <div class="col-sm-4">
                            <button type="submit" class="btn btn-primary">Save</button>
                        </div>
                    </div>
                    <br>
                </form>
            </div>
        </div>
    </div>
    <!--/ Basic Bootstrap Table -->
</div>

<script>
    $(document).ready(function() {
        $('#gameid').change(function() {
            const gameId = $(this).val();
            const resultDropdown = $('#result');
            resultDropdown.empty(); // Clear previous options
            resultDropdown.append('<option value="">Select Option</option>');

            if (gameId) {
                $.ajax({
                    url: "<?php echo e(route('gameOptions')); ?>",
                    method: "POST",
                    data: {
                        _token: "<?php echo e(csrf_token()); ?>",
                        game_id: gameId
                    },
                    success: function(response) {
                        response.answers.forEach(function(answer) {
                            resultDropdown.append(
                                `<option value="${answer}">${answer}</option>`
                            );
                        });
                    }
                });
            }
        });
    });
</script><?php /**PATH C:\xampp\htdocs\Matka_app\resources\views/Admin/Results/ResultDashboard.blade.php ENDPATH**/ ?>