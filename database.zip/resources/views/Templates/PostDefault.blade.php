<h1>
    {{ $post->title }}
</h1>