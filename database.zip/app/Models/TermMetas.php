<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TermMetas extends Model
{
	/**Table Name**/
	protected $table = 'term_metas';
}
