<!-- Internet Connection Status-->
<div class="internet-connection-status" id="internetStatus"></div>
<!-- Footer Nav-->
<div class="footer-nav-area" id="footerNav">
  <div class="suha-footer-nav">
    <ul class="h-100 d-flex align-items-center justify-content-between ps-0 d-flex rtl-flex-d-row-r">
      <li><a href="<?php echo e(route('user-dashboard')); ?>"><i class="ti ti-home"></i>Home</a></li>
      <li><a href="<?php echo e(route('myBids')); ?>"><i class="ti ti-message"></i>MyBid</a></li>
      <li><a href="<?php echo e(route('transaction')); ?>"><i class="ti ti-basket"></i>Transaction</a></li>
      <li><a href="<?php echo e(route('resultPage')); ?>"><i class="ti ti-settings"></i>Results</a></li>
      <li><a href="<?php echo e(route('profile')); ?>"><i class="ti ti-heart"></i>Profile</a></li>
    </ul>
  </div><?php /**PATH C:\xampp\htdocs\Matka_app\resources\views/Include/FooterMenu.blade.php ENDPATH**/ ?>