<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TermRelations extends Model
{
	/**Table Name**/
	protected $table = 'term_relationships';
}
