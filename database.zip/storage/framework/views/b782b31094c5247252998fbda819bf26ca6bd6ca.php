<div class="intro-wrapper d-flex align-items-center justify-content-center text-center">
    <div class="container"><img class="big-logo" src="..\themeAssets\img\matka\matka.png" alt=""></div>
</div>


<script>
    window.onload = function() {
        setTimeout(function() {
            window.location.href = "<?php echo e(route('registerpage')); ?>";
        }, 5000);
    };
</script>
<?php /**PATH C:\xampp\htdocs\Matka_app\resources\views/Templates/Welcome.blade.php ENDPATH**/ ?>