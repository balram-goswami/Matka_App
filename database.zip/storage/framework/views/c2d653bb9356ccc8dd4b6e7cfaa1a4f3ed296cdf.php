<!-- CSS Libraries -->
<link rel="stylesheet" href="<?php echo e(publicPath('/themeAssets/css/bootstrap.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(publicPath('/themeAssets/css/tabler-icons.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(publicPath('/themeAssets/css/animate.css')); ?>">
<link rel="stylesheet" href="<?php echo e(publicPath('/themeAssets/css/owl.carousel.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(publicPath('/themeAssets/css/magnific-popup.css')); ?>">
<link rel="stylesheet" href="<?php echo e(publicPath('/themeAssets/css/nice-select.css')); ?>">
<!-- Stylesheet -->
<link rel="stylesheet" href="<?php echo e(publicPath('/themeAssets/style.css')); ?>">
<!-- Web App Manifest -->
<link rel="manifest" href="<?php echo e(publicPath('/themeAssets/manifest.json')); ?>"><?php /**PATH C:\xampp\htdocs\Matka_app\resources\views/Include/Style.blade.php ENDPATH**/ ?>