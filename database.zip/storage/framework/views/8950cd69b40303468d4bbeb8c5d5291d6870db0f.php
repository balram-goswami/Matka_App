<!-- Header Area-->
<div class="header-area" id="headerArea">
    <div class="container h-100 d-flex align-items-center justify-content-between rtl-flex-d-row-r">
        <!-- Back Button-->
        <div class="back-button me-2"><a href="<?php echo e(route('user-dashboard')); ?>"><i class="ti ti-arrow-left"></i></a></div>
        <!-- Page Title-->
        <div class="page-heading">
            <h6 class="mb-0">Bids</h6>
        </div>
        <!-- Navbar Toggler-->
        <div class="suha-navbar-toggler ms-2" data-bs-toggle="offcanvas" data-bs-target="#suhaOffcanvas"
            aria-controls="suhaOffcanvas">
            <div><span></span><span></span><span></span></div>
        </div>
    </div>
</div>

<?php echo $__env->make('Include.SideMenuOptions', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="page-content-wrapper">
    <div class="container">
        <!-- Cart Wrapper-->
        <div class="cart-wrapper-area py-3">
            <div class="cart-table card mb-3">
                <div class="table-responsive card-body">
                    <table class="table mb-0">
                        <thead>
                            <tr>
                                <th>Date</th>
                                <th>Name</th>
                                <th>My Bid</th>
                                <th>Amount</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $bids; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bid): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php 
                            $gameName = postName($bid->game_id);
                            ?>
                                <tr>
                                    <td><?php echo e($bid->updated_at); ?></td>
                                    <td><?php echo e($gameName->post_title); ?></td>
                                    <td><?php echo e($bid->answer); ?></td>
                                    <td><?php echo e($bid->bid_amount); ?></td>
                                    <?php if($bid->result_status == 'win'): ?>
                                        <td>
                                            <?php if($bid->result_status == 'win'): ?>
                                            <a href="<?php echo e(route('claimAmount', ['bid_id' => $bid->id])); ?>">Get Amount</a>
                                            <?php endif; ?>
                                        </td>
                                    <?php elseif($bid->result_status === 'claimed'): ?>
                                        <td style="color: green">Win</td>
                                    <?php elseif($bid->bid_result == NULL): ?>
                                        <td style="color: yellow">Wait For Result</td>
                                    <?php else: ?>
                                        <td style="color: red">Loss</td>
                                    <?php endif; ?>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php echo $__env->make('Include.FooterMenu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\xampp\htdocs\Matka_app\resources\views/Templates/MyBids.blade.php ENDPATH**/ ?>